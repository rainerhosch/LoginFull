<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *  Copyright 03 oktober 2019 | PT AZL-TECH
 *  
 *  Author : Rizky Oktan
 */

class Auth extends CI_Controller
{
	// public function __construct()
	// {
	// 	parent::__construct();
	// 	$this->load->library('form_validation');
	// }

	public function index()
	{
		// block akses url auth ketika ada session
		if ($this->session->userdata('email')) {
			redirect('user');
		}

		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email', [
			'required' => 'data tidak boleh kosong!',
			'valid_email' => 'Alamat email tidak valid!'
		]);
		$this->form_validation->set_rules('password', 'Password', 'trim|required', [
			'required' => 'data tidak boleh kosong!'
		]);
		if ($this->form_validation->run() == false) {

			$data['title'] = 'Form Login';
			$this->load->view('templates/auth-header', $data);
			$this->load->view('auth/login');
			$this->load->view('templates/auth-footer');
		} else {
			//Validasi sukses
			$this->_login();
		}
	}

	//Metod Login
	private function _login()
	{
		$email = $this->input->post('email');
		$password = $this->input->post('password');

		//query
		$user = $this->db->get_where('user', ['email' => $email])->row_array();

		//data ditemukan
		if ($user) {
			//cek status aktiv email
			if ($user['status_active'] == 1) {
				// jika akun aktif cek password
				if (password_verify($password, $user['password'])) {
					$data = [
						'email' => $user['email'],
						'role_id' => $user['role_id']
					];
					$this->session->set_userdata($data);

					//cek role
					if ($user['role_id'] == 1) {
						redirect('admin/home');
					} else {
						redirect('profile');
					}
				} else {
					// password salah
					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Password salah!. </div>');
					redirect('auth');
				}
			} else {
				// tidak ada data
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Akun belum diaktivasi! silahkan cek email anda untuk aktivasi akun. </div>');
				redirect('auth');
			}
		} else {
			// tidak ada data
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email tidak terdaftar, atau belum terkait dengan akun manapun. </div>');
			redirect('auth');
		}
	}

	//Metod Registrasi
	public function registration()
	{
		// block akses url auth ketika ada session
		if ($this->session->userdata('email')) {
			redirect('user');
		}
		$this->form_validation->set_rules('nama', 'Nama', 'required|trim', [
			'required' => 'data tidak boleh kosong!'
		]);
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[user.email]', [
			'required' => 'data tidak boleh kosong!',
			'valid_email' => 'Alamat email tidak valid!',
			'is_unique' => 'email sudah terdaftar!, silahkan gunakan alamat email yang lain.'
		]);
		$this->form_validation->set_rules('password1', 'Password', 'required|trim|min_length[3]|matches[password2]', [
			'required' => 'data tidak boleh kosong!',
			'matches' => 'password tidak sesuai!',
			'min_length' => ' password terlalu pendek!'
		]);
		$this->form_validation->set_rules('password2', 'Password', 'required|trim|matches[password1]');

		if ($this->form_validation->run() == false) {

			$data['title'] = 'Form Pendaftaran';
			$this->load->view('templates/auth-header', $data);
			$this->load->view('auth/registration');
			$this->load->view('templates/auth-footer');
		} else {
			$reg_email = $this->input->post('email', true);

			$data  = [
				'nama' => htmlspecialchars($this->input->post('nama', true)),
				'email' => htmlspecialchars($reg_email),
				'notlp' => '+62',
				'image' => 'default.jpg',
				'password' => password_hash($this->input->post('password1'), PASSWORD_DEFAULT),
				'role_id' => 2,
				'status_active' => 0,
				'date_create' => time()
			];

			//token registrasi
			$token = base64_encode(random_bytes(32));
			$user_token = [
				'email' => $reg_email,
				'token' => $token,
				'date_created' => time()
			];

			//insert data registrasi
			$this->db->insert('user', $data);
			$this->db->insert('user_token', $user_token);

			// kirim email aktivasi
			$this->_sendEmail($token, 'verify');



			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Registrasi berhasil! silahkan aktivasi akun anda, melalui email verivikasi yang dikirim.</div>');
			redirect('auth');
		}
	}

	private function _sendEmail($token, $type)
	{
		$data = [
			'nama' => $this->input->post('nama'),
			'email' =>  $this->input->post('email')
		];

		$config = [
			'protocol' => 'smtp',
			'smtp_host' => 'ssl://smtp.googlemail.com',
			'smtp_user' => 'oktan.tech@gmail.com',
			'smtp_pass' => 'rizky1994',
			'smtp_port' => 465,
			'mailtype' => 'html',
			'charset' => 'utf-8',
			'newline' => "\r\n",
		];

		//call lib email CI
		$this->load->library('email', $config);
		$this->email->initialize($config);

		//kirim email
		$this->email->from('oktan.tech@gmail.com', 'OKTAN-TECH');
		$this->email->to($this->input->post('email'));

		if ($type == 'verify') {

			$this->email->subject('Verifikasi Mail');
			$this->email->message('
			<h1>
			Hai, ' . $data['nama'] . '
			</h1>
			<br>
			<p>Silahkan klik link berikut, untuk mengaktifkan akun anda : 
				<a href="' . base_url() . 'auth/akunverifikasi?email=' . $data['email'] . '&token=' . urlencode($token) . '">Aktivasi</a>
			');
		} else if ($type == 'forgot') {

			$this->email->subject('Reset Password');
			$this->email->message('
			<h1>
			Hai, ' . $data['nama'] . '
			</h1>
			<br>
			<p>Apakah anda mengirimkan permintaan reset password ?</p>
			<p>abaikan pesan ini jika anda tidak melakukannya</p>
			<p>Silahkan klik link berikut, jika anda ingin merubah password : 
				<a href="' . base_url() . 'auth/resetpassword?email=' . $data['email'] . '&token=' . urlencode($token) . '">Reset Password</a>
			');
		}

		if ($this->email->send()) {
			return true;
		} else {
			echo $this->email->print_debugger();
			die();
		}
	}

	public function akunVerifikasi()
	{
		$email = $this->input->get('email');
		$token = $this->input->get('token');

		$user = $this->db->get_where('user', ['email' => $email])->row_array();

		if ($user) {
			$user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();
			if ($user_token) {
				//code
				if (time() - $user_token['date_created'] < (60 * 60 * 24)) {
					$this->db->set('status_active', 1);
					$this->db->where('email', $email);
					$this->db->update('user');

					//delete user token
					$this->db->delete('user_token', ['email' => $email]);

					//pesan
					$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Aktivasi' . $email . ' berhasil! silahkan login.</div>');
					redirect('auth');
				} else {
					$this->db->delete('user', ['email', $email]);
					$this->db->delete('user_token', ['email', $email]);
					//pesan
					$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Aktivasi gagal! Token tidak berlaku.</div>');
					redirect('auth');
				}
			} else {
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Aktivasi gagal! Token tidak dikenal.</div>');
				redirect('auth');
			}
		} else {
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Aktivasi gagal! Email tidak dikenal.</div>');
			redirect('auth');
		}
	}

	//Mentod Logout
	public function logout()
	{
		//hapus data session
		$this->session->unset_userdata('email');
		$this->session->unset_userdata('role_id');

		//redirect ke page awal
		$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Berhasil logout.</div>');
		redirect('auth');
	}

	// untuk lupa password
	public function forgotPassword()
	{
		$this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email', [
			'required' => 'data tidak boleh kosong!',
			'valid_email' => 'Alamat email tidak valid!'
		]);
		if ($this->form_validation->run() == false) {
			$data['title'] = 'Lupa Password';
			$this->load->view('templates/auth-header', $data);
			$this->load->view('auth/forgot-password');
			$this->load->view('templates/auth-footer');
		} else {
			$email = $this->input->post('email');
			$user = $this->db->get_where('user', [
				'email' => $email,
				'status_active' => 1
			])->row_array();

			//code
			if ($user) {
				//token registrasi
				$token = base64_encode(random_bytes(32));
				$user_token = [
					'email' => $email,
					'token' => $token,
					'date_created' => time()
				];

				$this->db->insert('user_token', $user_token);
				$this->_sendEmail($token, 'forgot');

				$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Email reset password telah terkirim! Silahkan cek email anda.</div>');
				redirect('auth/forgotpassword');
			} else {
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Email belum terdaftar atau belum diaktivasi.</div>');
				redirect('auth/forgotpassword');
			}
		}
	}

	//methor reset password
	public function resetPassword()
	{
		$email = $this->input->get('email');
		$token = $this->input->get('token');

		$user = $this->db->get_where('user', ['email' => $email])->row_array();

		if ($user) {

			$user_token = $this->db->get_where('user_token', ['token' => $token])->row_array();

			if ($user_token) {
				//
				$this->session->set_userdata('reset_email', $email);
				$this->changePassword();
			} else {
				//pesan error
				$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Reset tidak dapat dilakukan! Token tidak berlaku.</div>');
				redirect('auth');
			}
		} else {
			$this->session->set_flashdata('message', '<div class="alert alert-danger" role="alert">Reset tidak dapat dilakukan! Email salah.</div>');
			redirect('auth');
		}
	}


	//method rubah password
	public function changePassword()
	{
		if (!$this->session->userdata('reset_email')) {
			redirect('auth');
		}
		//form validasi
		$this->form_validation->set_rules('password1', 'Password ', 'required|trim|min_length[3]|matches[password2]', [
			'required' => 'data tidak boleh kosong!',
			'matches' => 'password tidak sesuai!',
			'min_length' => ' password terlalu pendek!'
		]);
		$this->form_validation->set_rules('password2', 'Repeat Password', 'required|trim|matches[password1]', [
			'required' => 'data tidak boleh kosong!',
			'matches' => 'password yang dimasukan, tidak sesuai dengan passwor di kolom 1!',
			'min_length' => ' password terlalu pendek!'
		]);

		//code
		if ($this->form_validation->run() == false) {
			$data['title'] = 'Ganti Password';
			$this->load->view('templates/auth-header', $data);
			$this->load->view('auth/change-password');
			$this->load->view('templates/auth-footer');
		} else {
			$password = password_hash($this->input->post('password1'), PASSWORD_DEFAULT);
			$email = $this->session->userdata('reset_email');

			$this->db->set('password', $password);
			$this->db->where('email', $email);
			$this->db->update('user');

			//hapus session
			$this->session->unset_userdata('reset_email');

			$this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Password berhasil diubah! Silahkan login.</div>');
			redirect('auth');
		}
	}

	// public function block()
	// {
	// 	$data['title'] = '403 Gengs!';
	// 	// $this->session->set_userdata($data);
	// 	$this->load->view('templates/header', $data);
	// 	$this->load->view('auth/403');
	// }
}
