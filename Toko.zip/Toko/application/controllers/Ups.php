<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *  Copyright 03 oktober 2019 | PT AZL-TECH
 *  
 *  Author : Rizky Oktan
 */

class Ups extends CI_Controller
{
    public function index()
    {
        $data['title'] = '403 Gengs!';
        $this->load->view('templates/header', $data);
        $this->load->view('auth/403');
    }
}
