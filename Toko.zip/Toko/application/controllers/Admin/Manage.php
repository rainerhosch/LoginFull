<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *  Copyright 03 oktober 2019 | PT AZL-TECH
 *  
 *  Author : Rizky Oktan
 */

class Manage extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        //load helper chechin
        is_access();
        //load model menu
        $this->load->model('Menu_model', 'menu');
    }

    /**
     *  Method manage role access
     */
    public function role()
    {
        //
        $data['title'] = 'Role User';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        // method mengambil data 'role_user' dari database
        $data['role'] = $this->db->get('user_role')->result_array();

        // method form validasi
        $this->form_validation->set_rules('role', 'Role', 'required', [
            'required' => 'data `Role` tidak boleh kosong!'
        ]);
        // jika form validasi tidak ada maka, tampilkan 'Tabel Data'
        if ($this->form_validation->run() == false) {

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/menu/role', $data);
            $this->load->view('templates/footer');
        } else {
            //kondisi->jika form validasi ditemukan->lakukan insert data
            $this->db->insert('user_role', [
                'role' => $this->input->post('role')
            ]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">role baru telah ditambahkan!. </div>');
            redirect('admin/manage/role');
        }
    }

    //edit role
    public function edit_role()
    {

        $role = $this->uri->segment(3);
        $id['id'] = $this->db->get_where('user_role', ['role' => $role])->row_array();
        var_dump($id);
        die();

        $this->db->update('user_role', [
            'role' => $this->input->post('role')
        ]);
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">role berhasil di ubah!. </div>');
        redirect('admin/manage/role');
    }

    //hapus role
    public function hapus_role()
    {

        $data = $this->uri->segment(3);
        $this->db->delete('user_role', ['role' => $data]);

        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">data berhasil dihapus!. </div>');
        redirect('admin/manage/role');
    }

    //set acces
    public function roleAccess($role_id)
    {
        $data['title'] = 'Role Access';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        // method mengambil data 'role_user' dari database
        $data['role'] = $this->db->get_where('user_role', ['id' => $role_id])->row_array();
        //nyembunyikan admin menu
        $this->db->where('id !=', 1);
        //get data menu
        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/menu/role-access', $data);
        $this->load->view('templates/footer');
    }

    //ubah access
    public function changeaccess()
    {
        $menu_id = $this->input->post('menuId');
        $role_id = $this->input->post('roleId');

        $data = [
            'role_id' => $role_id,
            'menu_id' => $menu_id
        ];
        $result = $this->db->get_where('user_access_menu', $data);
        if ($result->num_rows() < 1) {
            $this->db->insert('user_access_menu', $data);
        } else {
            $this->db->delete('user_access_menu', $data);
        }
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert"> Akses berhasil diubah!</div>');
    }

    /**
     *  Method manage menu
     */
    public function menu()
    {
        //
        $data['title'] = 'Menu Menejemen';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['menu'] = $this->db->get('user_menu')->result_array();

        $this->form_validation->set_rules('menu', 'Menu', 'required', [
            'required' => 'data tidak boleh kosong!'
        ]);

        if ($this->form_validation->run() == false) {

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/menu/index', $data);
            $this->load->view('templates/footer');
        } else {
            $this->db->insert('user_menu', [
                'menu' => $this->input->post('menu')
            ]);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Menu baru telah ditambahkan!. </div>');
            redirect('menu');
        }
    }



    public function subMenu()
    {
        $data['title'] = 'SubMenu Menejemen';
        $data['user'] = $this->db->get_where('user', ['email' => $this->session->userdata('email')])->row_array();

        $data['subMenu'] = $this->menu->getSubMenu();
        $data['menu'] = $this->db->get('user_menu')->result_array();

        // Form Validasi
        $this->form_validation->set_rules('title', 'Title', 'required', [
            'required' => 'Form `Judul` tidak boleh kosong!'
        ]);
        $this->form_validation->set_rules('menu_id', 'Menu', 'required', [
            'required' => '`Index Menu` belum dipilih!'
        ]);
        $this->form_validation->set_rules('url', 'Url', 'required', [
            'required' => 'Form `URL` tidak boleh kosong!'
        ]);
        $this->form_validation->set_rules('icon', 'Icon', 'required', [
            'required' => 'Form `ICON` tidak boleh kosong!'
        ]);

        // Kondisi Awal
        if ($this->form_validation->run() == false) {

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/menu/sub-menu', $data);
            $this->load->view('templates/footer');
        } else {
            $data = [
                'title' => $this->input->post('title'),
                'menu_id' => $this->input->post('menu_id'),
                'url' => $this->input->post('url'),
                'icon' => $this->input->post('icon'),
                'status_active' => $this->input->post('status_active')
            ];
            $this->db->insert('user_sub_menu', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Sub menu baru telah ditambahkan!. </div>');
            redirect('menu/submenu');
        }
    }
}
