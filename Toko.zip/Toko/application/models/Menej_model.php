<?php
defined('BASEPATH') or exit('No direct script access allowed');
/**
 *  File Menej_model
 * 
 * 
 *  Copyright 03 oktober 2019 | PT AZL-TECH
 * 
 *  Author : Rizky Oktan
 */

class Menu_model extends CI_Model
{
    function hapus_data($where, $table)
    {
        $this->db->where($where);
        $this->db->delete($table);
    }
}
