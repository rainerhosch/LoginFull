<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand -->
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?= base_url('user'); ?>">
        <div class="sidebar-brand-icon rotate-n-15">
            <i class="fas fa-cash-register"></i>
        </div>
        <div class="sidebar-brand-text mx-3">Mini<sup>kasir</sup></div>
    </a>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- QWERY DARI DATABASE MENU -->
    <?php
    $role_id = $user['role_id'];
    $queryMenu = "SELECT `user_menu`.`id`, `menu`, `menu_icon` 
                    FROM `user_menu` JOIN `user_access_menu` 
                        ON `user_menu`.`id` = `user_access_menu`.`menu_id` 
                    WHERE `user_access_menu`.`role_id` = $role_id 
                ORDER BY `user_access_menu`.`menu_id` ASC
                ";
    $menu = $this->db->query($queryMenu)->result_array();
    ?>

    <!-- Heading MENU BY QUERY-->
    <?php foreach ($menu as $mn) : ?>
        <?php if ($menu == $mn['menu']) : ?>
            <!-- Nav Item - Sub Menu -->
            <li class="nav-item active">
            <?php else : ?>
            <li class="nav-item">
            <?php endif; ?>
            <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#<?= $mn['menu']; ?>" aria-expanded="true" aria-controls="collapseUtilities">
                <i class="<?= $mn['menu_icon']; ?>"></i>
                <span>
                    <strong>
                        <?= $mn['menu']; ?>
                    </strong>
                </span>
            </a>
            <div id="<?= $mn['menu']; ?>" class="collapse" aria-labelledby="headingUtilities" data-parent="#accordionSidebar">
                <div class="bg-white py-2 collapse-inner rounded">
                    <h6 class="collapse-header"> <?= $mn['menu']; ?>:</h6>
                    <?php

                    $menuId = $mn['id'];
                    $statusMenuActive = 1;
                    $querySubMenu = "SELECT *
                            FROM `user_sub_menu` JOIN `user_menu` 
                                ON `user_sub_menu`.`menu_id` = `user_menu`.`id`
                            WHERE `user_sub_menu`.`menu_id` = $menuId
                            AND `user_sub_menu`.`status_active` = $statusMenuActive
                            ";
                    $subMenu = $this->db->query($querySubMenu)->result_array();
                    ?>
                    <?php foreach ($subMenu as $sm) :
                        if ($mn['menu']  == 'Profile') {
                            $link = $sm['url'] . '?user=' . $user['nama'];
                        } else {
                            $link = $sm['url'];
                        }
                    ?>
                        <a class="collapse-item" href="<?= base_url($link); ?>"><i class="<?= $sm['icon']; ?>"></i> <span><?= $sm['title']; ?></span></a>
                    <?php endforeach; ?>
                </div>
            </div>
            </li>
            <!-- Divider -->
            <!-- <hr class="sidebar-divider"> -->
        <?php endforeach; ?>
        <!-- end dropdown menu -->

        <!-- Sidebar Toggler (Sidebar) -->
        <div class="text-center d-none d-md-inline">
            <button class="rounded-circle border-0" id="sidebarToggle"></button>
        </div>

</ul>
<!-- End of Sidebar -->