<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800">Halo, <?= $user['nama']; ?></h1>

    <div class="row">
        <div class="col-lg-6">
            <?= $this->session->flashdata('message'); ?>
        </div>
    </div>

    <div class="card border-secondary mb-3" style="max-width: 800px;">
        <div class="row no-gutters">
            <div class="col-md-4 m-1">
                <img src="<?= base_url('assets/img/profile/') .  $user['image']; ?>" class="card-img border border-light" alt="...">
            </div>
            <div class="col-md-7">
                <div class="card-body">
                    <h5 class="card-title"><strong>Profile</strong></h5>
                    <hr>
                    <div class="row mt-3">
                        <p>
                            <div class="col-sm-3">
                                <strong>Nama</strong>
                            </div>
                            <div class="col-sm-9">
                                <?= $user['nama']; ?>
                            </div>
                        </p>
                        <p>
                            <div class="col-sm-3">
                                <strong>Email</strong>
                            </div>
                            <div class="col-sm-9">
                                <?= $user['email']; ?>
                            </div>
                        </p>
                        <p>
                            <div class="col-sm-3">
                                <strong>No Hp</strong>
                            </div>
                            <div class="col-sm-9">
                                <?= $user['notlp']; ?>
                            </div>
                        </p>
                    </div>
                    <p class="card-text mt-5"><small class="text-muted">Bergabung sejak, <?= date('d F Y', $user['date_create']); ?> </small></p>
                </div>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->