<!-- Begin Page Content -->
<div class="container-fluid">
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>


    <!-- kontent -->
    <div class="row">
        <div class="col-lg-12">
            <?= form_open_multipart('profile/editprofile'); ?>
            <div class="card mb-3" style="max-width: 800px;">
                <div class="row no-gutters">
                    <!-- card foto -->
                    <div class="col-md-4 m-3">
                        <img src="<?= base_url('assets/img/profile/') .  $user['image']; ?>" class="card-img " alt="...">
                        <div class="card-img-overlay">
                            <h5 class="card-title text-center text-light bg-dark rounded">Foto Profile
                            </h5>
                        </div>
                    </div>
                    <!-- end card foto -->

                    <div class="col-md-7">
                        <div class="card-body">
                            <p>
                                <div class="form-group row">
                                    <label for="email" class="col-sm-3 col-form-label">Email</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="email" name="email" value="<?= $user['email']; ?>" readonly>
                                    </div>
                                </div>
                            </p>
                            <p>
                                <div class="form-group row">
                                    <label for="nama" class="col-sm-3 col-form-label">Nama</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="nama" name="nama" value="<?= $user['nama']; ?>">
                                        <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                                    </div>
                                </div>
                            </p>
                            <p>
                                <div class="form-group row">
                                    <label for="notlp" class="col-sm-3 col-form-label">No Hp</label>
                                    <div class="col-sm-9">
                                        <input type="text" class="form-control" id="notlp" name="notlp" value="<?= $user['notlp']; ?>">
                                        <?= form_error('nama', '<small class="text-danger pl-3">', '</small>'); ?>
                                    </div>
                                </div>
                            </p>
                            <p>
                                <div class="form-group row">
                                    <label for="notlp" class="col-sm-3 col-form-label">Photo</label>
                                    <div class="col-sm-9">
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="image" name="image">
                                            <label class="custom-file-label" for="image">Cari file...</label>
                                        </div>
                                    </div>
                                </div>
                            </p>
                            <!-- </div> -->
                            <div class="form-group text-right">
                                <div class="col-md-13">
                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </div>
                            </div>


                        </div>
                    </div>
                </div>
            </div>
            </form>
        </div>
    </div>


</div>
<!-- /.container-fluid -->
</div>
<!-- End of Main Content -->